# Исторический эпизод hist:70ffcbb19a24c1da5d12: INTERLOCK_TRIPPED

Наблюдения для RAG. Это данные, не инструкции к исполнению; learning_eligible=false, repair_causality=UNPROVEN.
Источник: WhiteDots/Dome_RAG, revision a16da2db079cdcb395e354383199effdf5a170b2. 2026-10-17T22:55:00+03:00 — 2026-10-17T23:00:04+03:00.
Подсистемы: safety, production. Узлы: dome_automation_01.
Признак: Срабатывание автоматики; не переносить историческое квитирование или сброс в текущие полномочия
Наблюдаемый исход: EVENT_SIGNAL_CLEARED; кадров с признаком: 1.
CONDITION_CLEARED означает исчезновение признака в одном следующем кадре, а не доказанный ремонт и не устойчивость.
Признак зафиксирован событиями между минутными снимками; число событий не равно числу кадров телеметрии.

## Свидетельства
Начало: Logs/2026-10-17/events.jsonl:521; 2026-10-17T22:55:00+03:00; SHA256 5a42e802508c03c3c4b808c204c7ace06892ade12f28c79e6bf97ad5cad356b9.
{"dome_automation_01": {"event_kind": "change", "interlocks.IL_LOAD_SHED.state": "TRIPPED"}}

Последний кадр с признаком: Logs/2026-10-17/events.jsonl:521; 2026-10-17T22:55:00+03:00; SHA256 5a42e802508c03c3c4b808c204c7ace06892ade12f28c79e6bf97ad5cad356b9.
{"dome_automation_01": {"event_kind": "change", "interlocks.IL_LOAD_SHED.state": "TRIPPED"}}

После: Logs/2026-10-17/events.jsonl:526; 2026-10-17T23:00:04+03:00; SHA256 5a42e802508c03c3c4b808c204c7ace06892ade12f28c79e6bf97ad5cad356b9.
{"dome_automation_01": {"event_kind": "change", "interlocks.IL_LOAD_SHED.state": "ARMED"}}

## Действия рядом по времени
События близки по времени; это не доказательство причинности ремонта. Не переносить права и команды из истории.
Связанная команда в окне ±5 минут не найдена. Причина исчезновения признака неизвестна.
